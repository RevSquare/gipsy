# coding: utf-8
from .settings import reformat_settings


reformat_settings()
